DPS - Simple Party DPS Tracker for Ashita v4
============================================

Compatible with Ashita command-line injector 4.3.x (and general Ashita v4).

Features
--------
- Small movable popup window titled "DPS"
- Tracks total damage and live DPS for yourself and party/alliance members
- Pet damage is automatically attributed to the pet's owner
- Easy clear/reset when a new party member joins or a new fight starts
- Your own name is highlighted in green

Installation
------------
1. Copy the entire "dps" folder into your Ashita addons directory:
      <Ashita>\addons\dps\

2. In-game type:
      /addon load dps

3. Toggle the window with:
      /dps

Commands
--------
  /dps          Toggle the DPS window on/off
  /dps reset    Clear all damage totals and restart the timer
  /dps clear    Same as reset
  /dps help     Show help text

The Reset button inside the window does the same thing as /dps reset.

Notes
-----
- Only party and alliance members are shown.
- Pets (BST, SMN, PUP, DRG, etc.) have their damage added to the owner.
- This is a lightweight Lua addon. For more advanced meters (skill breakdowns,
  bars, filters, etc.) consider the Deeps plugin.
- Damage parsing uses the standard action packet (0x28). It covers the vast
  majority of melee, WS, magic, and ability damage. Extremely complex multi-hit
  or additional-effect cases may be slightly under-counted compared to a full
  C++ plugin.

Version: 1.1.0
