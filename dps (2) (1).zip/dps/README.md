# DPS

Simple party **DPS + accuracy** tracker for **Ashita v4** (Final Fantasy XI).

A lightweight Lua addon with a movable window showing damage, DPS, and accuracy for you and your party/alliance. Pet damage is attributed to the owner. Healing is ignored. You can post a summary to party chat.

Compatible with Ashita command-line injector **4.3.x** and general Ashita v4.

---

## Features

- Movable ImGui window titled **DPS**
- Tracks total damage + live DPS for yourself and party/alliance members
- Tracks **hits / misses** and shows **accuracy %**
- **Pet damage** (BST, SMN, PUP, DRG, etc.) is added to the owner
- **Healing is ignored** — Cure, etc. never count as damage
- One-click **Reset** (or `/dps reset`) when a new party member joins or a new fight starts
- **Report to party** (or say / linkshell) with `/dps report`
- Automatically drops players who leave the party
- Your own name is highlighted in green

---

## Installation

1. Download the latest release or clone this repository.
2. Place the `dps` folder into your Ashita addons directory:

   ```
   <Ashita>\addons\dps\
   ```

3. In-game:

   ```
   /addon load dps
   ```

4. Toggle the window:

   ```
   /dps
   ```

To autoload, add `/addon load dps` to your Ashita startup script (e.g. `scripts\default.txt`).

---

## Commands

| Command              | Description                                      |
|----------------------|--------------------------------------------------|
| `/dps`               | Toggle the DPS window                            |
| `/dps reset`         | Clear all totals and restart the timer           |
| `/dps clear`         | Alias for `reset`                                |
| `/dps report`        | Post summary to **party** chat                   |
| `/dps report p`      | Same as above (party)                            |
| `/dps report s`      | Post summary to **say**                          |
| `/dps report l`      | Post summary to **linkshell**                    |
| `/dps help`          | Show help                                        |

Buttons in the window:

- **Report** → posts to party (same as `/dps report`)
- **Reset** → clears totals (same as `/dps reset`)

---

## Accuracy

Accuracy is calculated as:

```
hits / (hits + misses) × 100
```

- **Hits** = actions that landed and dealt damage
- **Misses** = attack miss messages only

---

## Notes & limitations

- Lightweight Lua addon focused on a clean DPS + accuracy popup.
- Uses action packet `0x28` with a whitelist of known damage and miss message IDs (same approach as Deeps). Healing messages are excluded.
- For advanced features (skill breakdowns, bars, filters, etc.) consider [Deeps](https://github.com/relliko/Deeps).

---

## License

Free to use, modify, and share. No warranty.
