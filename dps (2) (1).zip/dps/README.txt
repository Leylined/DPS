DPS - Simple Party DPS + Accuracy Tracker for Ashita v4
=======================================================

Compatible with Ashita command-line injector 4.3.x (and general Ashita v4).

Features
--------
- Small movable popup window titled "DPS"
- Tracks total damage, live DPS, and accuracy for you + party/alliance
- Pet damage is automatically attributed to the pet's owner
- Healing (Cure, etc.) is never counted as damage
- Report button / command posts a summary to party chat
- Easy clear/reset when a new party member joins or a new fight starts
- Your own name is highlighted in green

Installation
------------
1. Copy the entire "dps" folder into your Ashita addons directory:
      <Ashita>\addons\dps\

2. In-game type:
      /addon load dps

3. Toggle the window with:
      /dps

Commands
--------
  /dps                  Toggle the DPS window on/off
  /dps reset            Clear all totals and restart the timer
  /dps clear            Same as reset
  /dps report           Post summary to party chat
  /dps report p         Same as report (party)
  /dps report s         Post summary to say
  /dps report l         Post summary to linkshell
  /dps help             Show help text

Buttons in the window: Report (party) and Reset.

Accuracy
--------
  hits / (hits + misses) x 100

Notes
-----
- Only party and alliance members are shown.
- Pets (BST, SMN, PUP, DRG, etc.) have their damage added to the owner.
- Healing is never counted as damage.
- This is a lightweight Lua addon. For more advanced meters consider Deeps.

Version: 1.3.0
