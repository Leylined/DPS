# DPS

Simple party DPS tracker for **Ashita v4** (Final Fantasy XI).

A lightweight Lua addon that shows a small movable window with damage and DPS for you and your party/alliance members. Pet damage is attributed to the pet’s owner.

Compatible with Ashita command-line injector **4.3.x** and general Ashita v4.

---

## Features

- Movable ImGui window titled **DPS**
- Tracks total damage + live DPS for yourself and party/alliance members
- **Pet damage** (BST, SMN, PUP, DRG, etc.) is added to the owner
- One-click **Reset** (or `/dps reset`) to clear totals — useful when a new party member joins or a new fight starts
- Automatically drops players who leave the party
- Your own name is highlighted in green
- Minimal and non-intrusive

---

## Installation

1. Download the latest release or clone this repository.
2. Place the `dps` folder into your Ashita addons directory:

   ```
   <Ashita>\addons\dps\
   ```

   The folder should contain at least:

   ```
   dps/
   └── dps.lua
   ```

3. In-game, load the addon:

   ```
   /addon load dps
   ```

4. Toggle the window:

   ```
   /dps
   ```

To load it automatically on startup, add the following line to your Ashita startup script (e.g. `scripts\default.txt`):

```
/addon load dps
```

---

## Commands

| Command       | Description                                      |
|---------------|--------------------------------------------------|
| `/dps`        | Toggle the DPS window on/off                     |
| `/dps reset`  | Clear all damage totals and restart the timer    |
| `/dps clear`  | Alias for `reset`                                |
| `/dps help`   | Show help text                                   |

The **Reset** button inside the window does the same thing as `/dps reset`.

---

## Usage tips

- Click **Reset** (or type `/dps reset`) at the start of a new fight or when someone joins the party so the numbers stay meaningful.
- Only current party and alliance members are displayed.
- The window can be dragged freely; size is constrained but resizable within limits.

---

## Notes & limitations

- This is a lightweight Lua addon focused on a clean, simple DPS popup.
- Damage is parsed from the standard action packet (`0x28`) using a whitelist of known damage message IDs (same approach used by Deeps). Healing messages are explicitly excluded.
- Covers the vast majority of melee, weaponskill, magic, and ability damage.
- Very complex multi-hit or additional-effect edge cases may be slightly under-counted compared to a full C++ plugin such as [Deeps](https://github.com/relliko/Deeps).
- For advanced features (skill breakdowns, colored bars, filters, reporting, etc.) consider using **Deeps** instead.

---

## Credits

Built for Ashita v4. Packet and party/pet handling patterns drawn from the Ashita community and common open-source addons.

---

## License

Free to use, modify, and share. No warranty.
