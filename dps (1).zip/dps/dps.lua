--[[
* DPS - Simple party DPS tracker for Ashita v4
* Compatible with Ashita command-line injector 4.3.x
*
* Features:
*   - Tracks damage + DPS for yourself and party/alliance members
*   - Pet damage is attributed to the pet's owner
*   - Reset / clear damage totals at any time (new party members, new fight, etc.)
*   - Movable ImGui window
*
* Commands:
*   /dps          - Toggle the DPS window
*   /dps reset    - Clear all damage totals and restart the timer
*   /dps clear    - Alias for reset
*   /dps help     - Show help
*
* Load with: /addon load dps
]]

addon.name      = 'dps';
addon.author    = 'Grok';
addon.version   = '1.2.0';
addon.desc      = 'Simple party DPS tracker. Pet damage counts toward the owner. Healing is ignored.';
addon.link      = '';

require('common');
local chat  = require('chat');
local imgui = require('imgui');

--=============================================================================
-- State
--=============================================================================
local dps = {
    is_open     = { true },
    start_time  = os.clock(),
    players     = {},          -- [server_id] = { name, damage }
    player_id   = 0,
};

-- Message IDs that represent actual damage dealt (not healing, buffs, misses, etc.)
-- Based on the well-tested lists used by Deeps and community parsers.
local DAMAGE_MESSAGES = {
    [1]   = true,  -- hits for X damage
    [2]   = true,  -- casts spell, target takes X damage
    [67]  = true,  -- critical hit
    [77]  = true,  -- ranged / some ability damage
    [110] = true,  -- ability damage variants
    [132] = true,  -- drains / certain damage
    [157] = true,  -- ranged / skill damage
    [161] = true,  -- additional hit damage
    [163] = true,  -- additional effect damage
    [185] = true,  -- weaponskill damage
    [187] = true,  -- weaponskill / ability damage
    [196] = true,  -- some skill damage
    [197] = true,  -- some skill damage
    [227] = true,  -- some ability damage
    [252] = true,  -- magic burst / critical magic
    [264] = true,  -- takes X damage (generic)
    [265] = true,  -- magic burst takes X damage
    [274] = true,  -- critical magic / skill
    [281] = true,  -- ability damage
    [317] = true,  -- skill / ability damage
    [352] = true,  -- ranged attack damage
    [353] = true,  -- critical ranged
    [379] = true,  -- critical magic burst etc.
    [413] = true,  -- skillchain / certain damage
    [522] = true,  -- additional damage forms
    [576] = true,  -- ranged hit squarely
    [577] = true,  -- ranged struck true
};

local function is_damage_message(message_id)
    return DAMAGE_MESSAGES[message_id] == true;
end


--=============================================================================
-- Helpers
--=============================================================================
local function get_player_id()
    local party = AshitaCore:GetMemoryManager():GetParty();
    if party then
        return party:GetMemberServerId(0) or 0;
    end
    return 0;
end

local function get_entity_name(server_id)
    local entMgr = AshitaCore:GetMemoryManager():GetEntity();
    for i = 0, 2302 do
        if entMgr:GetServerId(i) == server_id then
            local name = entMgr:GetName(i);
            if name and name ~= '' then
                return name;
            end
        end
    end
    return string.format('ID:%d', server_id);
end

--- Returns true if the given server_id belongs to a party/alliance member.
local function is_party_member(server_id)
    if server_id == 0 then return false; end
    if server_id == dps.player_id then return true; end

    local party = AshitaCore:GetMemoryManager():GetParty();
    if not party then return false; end

    for i = 0, 17 do
        if party:GetMemberIsActive(i) == 1 and party:GetMemberServerId(i) == server_id then
            return true;
        end
    end
    return false;
end

--- If the actor is a pet of a party/alliance member, return the owner's server_id.
--- Otherwise return the original actor_id (or 0 if not relevant).
local function resolve_to_owner(actor_id)
    if actor_id == 0 then return 0; end

    -- Already a party member?
    if is_party_member(actor_id) then
        return actor_id;
    end

    -- Check if this actor is the pet of any alliance member
    local party  = AshitaCore:GetMemoryManager():GetParty();
    local entMgr = AshitaCore:GetMemoryManager():GetEntity();
    if not party or not entMgr then return 0; end

    for i = 0, 17 do
        if party:GetMemberIsActive(i) == 1 then
            local playerIndex = party:GetMemberTargetIndex(i);
            if playerIndex and playerIndex > 0 then
                local petIndex = entMgr:GetPetTargetIndex(playerIndex);
                if petIndex and petIndex > 0 then
                    local petServerId = entMgr:GetServerId(petIndex);
                    if petServerId == actor_id then
                        -- Found the owner
                        return party:GetMemberServerId(i);
                    end
                end
            end
        end
    end

    -- Not a party member and not a party pet
    return 0;
end

local function add_damage(server_id, amount)
    if amount <= 0 or amount > 999999 then return; end
    if server_id == 0 then return; end

    -- Resolve pets to owners
    local owner_id = resolve_to_owner(server_id);
    if owner_id == 0 then return; end

    if not dps.players[owner_id] then
        dps.players[owner_id] = {
            name   = get_entity_name(owner_id),
            damage = 0,
        };
    end

    dps.players[owner_id].damage = dps.players[owner_id].damage + amount;

    -- Refresh name if it was unknown / placeholder
    local name = dps.players[owner_id].name;
    if not name or name:find('^ID:') or name == '' then
        dps.players[owner_id].name = get_entity_name(owner_id);
    end
end

local function reset_data()
    dps.players    = {};
    dps.start_time = os.clock();
    print(chat.header(addon.name):append(chat.message('Damage totals cleared. Timer restarted.')));
end

--- Remove anyone who is no longer in the party (optional housekeeping)
local function prune_left_members()
    local to_remove = {};
    for id, _ in pairs(dps.players) do
        if not is_party_member(id) then
            table.insert(to_remove, id);
        end
    end
    for _, id in ipairs(to_remove) do
        dps.players[id] = nil;
    end
end

--=============================================================================
-- Action packet parsing (0x28)
--=============================================================================
local function parse_action_packet(e)
    if e.id ~= 0x28 then return; end

    local data = e.data_raw;
    local bitOffset = 40;
    local maxBits = e.size * 8;

    local function unpack(bits)
        if (bitOffset + bits) > maxBits then
            return 0;
        end
        local val = ashita.bits.unpack_be(data, 0, bitOffset, bits);
        bitOffset = bitOffset + bits;
        return val;
    end

    local actor_id     = unpack(32);
    local target_count = unpack(6);
    bitOffset = bitOffset + 4;               -- padding / unknown
    local action_type  = unpack(4);          -- category
    unpack(32);                              -- action id / param
    bitOffset = bitOffset + 32;              -- recast / unknown

    -- Categories that commonly deal damage:
    -- 1  = Melee
    -- 2  = Ranged finish
    -- 3  = Weapon Skill
    -- 4  = Magic finish
    -- 6  = Job Ability
    -- 11 = NPC / mob skill
    -- 13 = Pet TP move
    -- 14 = Dancer JA
    -- 15 = Rune JA / similar
    local valid = {
        [1] = true, [2] = true, [3] = true, [4] = true,
        [6] = true, [11] = true, [13] = true, [14] = true, [15] = true,
    };
    if not valid[action_type] then return; end

    -- Resolve actor (or its owner) once
    local owner_id = resolve_to_owner(actor_id);
    if owner_id == 0 then return; end

    for _ = 1, target_count do
        unpack(32);                          -- target id
        local action_count = unpack(4);

        for _ = 1, action_count do
            unpack(5);                       -- reaction
            unpack(12);                      -- animation
            unpack(7);                       -- special effect
            unpack(3);                       -- knockback
            local param   = unpack(17);      -- main value (damage OR heal amount)
            local message = unpack(10);      -- message id
            unpack(31);                      -- flags

            -- Additional effect
            local add_param = 0;
            local add_message = 0;
            if unpack(1) == 1 then
                unpack(10);                  -- add-effect type
                add_param = unpack(17);
                add_message = unpack(10);    -- add-effect message
            end

            -- Spike / counter effect (skip values)
            if unpack(1) == 1 then
                unpack(10);
                unpack(14);
                unpack(10);
            end

            -- Only count real damage messages — never healing (Cure, etc.)
            if is_damage_message(message) and param > 0 and param < 100000 then
                add_damage(owner_id, param);
            end

            -- Additional-effect damage (e.g. enspell, drain variants that use damage msgs)
            if is_damage_message(add_message) and add_param > 0 and add_param < 100000 then
                add_damage(owner_id, add_param);
            end

        end
    end
end

--=============================================================================
-- Events
--=============================================================================
ashita.events.register('load', 'dps_load_cb', function()
    dps.player_id  = get_player_id();
    dps.start_time = os.clock();
    print(chat.header(addon.name):append(chat.message('Loaded. Type /dps to toggle the window.')));
    print(chat.header(addon.name):append(chat.message('Pet damage is added to the owner. Use /dps reset to clear.')));
end);

ashita.events.register('command', 'dps_command_cb', function(e)
    local args = e.command:args();
    if #args == 0 then return; end

    local cmd = string.lower(args[1]);
    if cmd ~= '/dps' then return; end

    e.blocked = true;

    if #args == 1 then
        dps.is_open[1] = not dps.is_open[1];
        return;
    end

    local sub = string.lower(args[2] or '');
    if sub == 'reset' or sub == 'clear' then
        reset_data();
    elseif sub == 'help' then
        print(chat.header(addon.name):append(chat.message('Commands:')));
        print(chat.header(addon.name):append(chat.message('/dps          Toggle the DPS window')));
        print(chat.header(addon.name):append(chat.message('/dps reset    Clear all damage & restart timer')));
        print(chat.header(addon.name):append(chat.message('/dps clear    Same as reset')));
        print(chat.header(addon.name):append(chat.message('/dps help     Show this help')));
    else
        print(chat.header(addon.name):append(chat.message('Unknown sub-command. Type /dps help')));
    end
end);

ashita.events.register('packet_in', 'dps_packet_in_cb', function(e)
    if e.id == 0x28 then
        -- Keep our own ID fresh (zone changes, etc.)
        local pid = get_player_id();
        if pid ~= 0 then
            dps.player_id = pid;
        end
        parse_action_packet(e);
    end
end);

--=============================================================================
-- Render
--=============================================================================
ashita.events.register('d3d_present', 'dps_present_cb', function()
    if not dps.is_open[1] then return; end

    -- Keep player id current
    local pid = get_player_id();
    if pid ~= 0 then
        dps.player_id = pid;
    end

    -- Optionally drop people who left the party
    prune_left_members();

    local elapsed = math.max(os.clock() - dps.start_time, 1.0);

    -- Build sorted list
    local list = {};
    local total_damage = 0;
    for id, p in pairs(dps.players) do
        table.insert(list, {
            id     = id,
            name   = p.name or get_entity_name(id),
            damage = p.damage or 0,
        });
        total_damage = total_damage + (p.damage or 0);
    end
    table.sort(list, function(a, b) return a.damage > b.damage; end);

    imgui.SetNextWindowSize({ 300, 0 }, ImGuiCond_FirstUseEver);
    imgui.SetNextWindowSizeConstraints({ 240, 120 }, { 520, 700 });

    if imgui.Begin('DPS', dps.is_open, ImGuiWindowFlags_NoCollapse) then
        -- Header row
        imgui.Text(string.format('Time: %.0fs', elapsed));
        imgui.SameLine();
        local btn_w = 60;
        imgui.SetCursorPosX(math.max(imgui.GetWindowWidth() - btn_w - 12, 100));
        if imgui.Button('Reset', { btn_w, 0 }) then
            reset_data();
        end
        if imgui.IsItemHovered() then
            imgui.SetTooltip('Clear all damage and restart the timer.\nUseful when a new party member joins or a new fight starts.');
        end

        imgui.Separator();

        if #list == 0 then
            imgui.TextColored({ 0.65, 0.65, 0.65, 1.0 }, 'No damage recorded yet.');
            imgui.TextColored({ 0.55, 0.55, 0.55, 1.0 }, 'Fight something or /dps reset');
        else
            -- Columns: Name | Damage | DPS
            imgui.Columns(3, 'dps_cols', false);
            imgui.SetColumnWidth(0, 120);
            imgui.SetColumnWidth(1, 80);
            imgui.SetColumnWidth(2, 70);

            imgui.Text('Name');
            imgui.NextColumn();
            imgui.Text('Damage');
            imgui.NextColumn();
            imgui.Text('DPS');
            imgui.NextColumn();
            imgui.Separator();

            for _, entry in ipairs(list) do
                local dps_val = entry.damage / elapsed;
                local is_me   = (entry.id == dps.player_id);

                if is_me then
                    imgui.TextColored({ 0.35, 1.0, 0.45, 1.0 }, entry.name);
                else
                    imgui.Text(entry.name);
                end
                imgui.NextColumn();

                imgui.Text(string.format('%d', entry.damage));
                imgui.NextColumn();

                imgui.Text(string.format('%.1f', dps_val));
                imgui.NextColumn();
            end

            imgui.Columns(1);
            imgui.Separator();
            imgui.Text(string.format('Party Total:  %d   (%.1f dps)',
                total_damage, total_damage / elapsed));
        end
    end
    imgui.End();
end);
