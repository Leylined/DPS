--[[
* DPS - Simple party DPS + accuracy tracker for Ashita v4
* Compatible with Ashita command-line injector 4.3.x
*
* Features:
*   - Tracks damage + DPS for yourself and party/alliance members
*   - Tracks hits / misses and shows accuracy %
*   - Pet damage is attributed to the pet's owner
*   - Healing is ignored (never counted as damage)
*   - Reset / clear totals at any time
*   - Report results to party chat
*   - Movable ImGui window
*
* Commands:
*   /dps              - Toggle the DPS window
*   /dps reset        - Clear all totals and restart the timer
*   /dps clear        - Alias for reset
*   /dps report       - Post summary to party chat
*   /dps report p     - Same as report (party)
*   /dps report s     - Post summary to say
*   /dps report l     - Post summary to linkshell
*   /dps help         - Show help
*
* Load with: /addon load dps
]]

addon.name      = 'dps';
addon.author    = 'Grok';
addon.version   = '1.3.3';
addon.desc      = 'Party DPS + accuracy tracker. Pet damage to owner. Healing ignored. Party report.';
addon.link      = '';

require('common');
local chat  = require('chat');
local imgui = require('imgui');

--=============================================================================
-- State
--=============================================================================
local dps = {
    is_open     = { true },
    start_time  = os.clock(),
    players     = {},          -- [server_id] = { name, damage, hits, misses }
    player_id   = 0,
};

-- Message IDs that represent actual damage dealt (not healing, buffs, etc.)
-- Same approach used by Deeps.
local DAMAGE_MESSAGES = {
    [1]   = true,  -- hits for X damage
    [2]   = true,  -- casts spell, target takes X damage
    [67]  = true,  -- critical hit
    [77]  = true,  -- ranged / some ability damage
    [110] = true,  -- ability damage variants
    [132] = true,  -- drains / certain damage
    [157] = true,  -- ranged / skill damage
    [161] = true,  -- additional hit damage
    [163] = true,  -- additional effect damage
    [185] = true,  -- weaponskill damage
    [187] = true,  -- weaponskill / ability damage
    [196] = true,  -- some skill damage
    [197] = true,  -- some skill damage
    [227] = true,  -- some ability damage
    [252] = true,  -- magic burst / critical magic
    [264] = true,  -- takes X damage (generic)
    [265] = true,  -- magic burst takes X damage
    [274] = true,  -- critical magic / skill
    [281] = true,  -- ability damage
    [317] = true,  -- skill / ability damage
    [352] = true,  -- ranged attack damage
    [353] = true,  -- critical ranged
    [379] = true,  -- critical magic burst etc.
    [413] = true,  -- skillchain / certain damage
    [522] = true,  -- additional damage forms
    [576] = true,  -- ranged hit squarely
    [577] = true,  -- ranged struck true
};

-- Miss messages (attack missed the target)
local MISS_MESSAGES = {
    [15]  = true,
    [85]  = true,
    [158] = true,
    [188] = true,
    [245] = true,
    [284] = true,
    [324] = true,
    [354] = true,
};

local function is_damage_message(id) return DAMAGE_MESSAGES[id] == true; end
local function is_miss_message(id)   return MISS_MESSAGES[id] == true; end

--=============================================================================
-- Helpers
--=============================================================================
local function get_player_id()
    local party = AshitaCore:GetMemoryManager():GetParty();
    if party then
        return party:GetMemberServerId(0) or 0;
    end
    return 0;
end

local function get_entity_name(server_id)
    local entMgr = AshitaCore:GetMemoryManager():GetEntity();
    for i = 0, 2302 do
        if entMgr:GetServerId(i) == server_id then
            local name = entMgr:GetName(i);
            if name and name ~= '' then
                return name;
            end
        end
    end
    return string.format('ID:%d', server_id);
end

local function is_party_member(server_id)
    if server_id == 0 then return false; end
    if server_id == dps.player_id then return true; end

    local party = AshitaCore:GetMemoryManager():GetParty();
    if not party then return false; end

    for i = 0, 17 do
        if party:GetMemberIsActive(i) == 1 and party:GetMemberServerId(i) == server_id then
            return true;
        end
    end
    return false;
end

--- If the actor is a pet of a party/alliance member, return the owner's server_id.
local function resolve_to_owner(actor_id)
    if actor_id == 0 then return 0; end
    if is_party_member(actor_id) then
        return actor_id;
    end

    local party  = AshitaCore:GetMemoryManager():GetParty();
    local entMgr = AshitaCore:GetMemoryManager():GetEntity();
    if not party or not entMgr then return 0; end

    for i = 0, 17 do
        if party:GetMemberIsActive(i) == 1 then
            local playerIndex = party:GetMemberTargetIndex(i);
            if playerIndex and playerIndex > 0 then
                local petIndex = entMgr:GetPetTargetIndex(playerIndex);
                if petIndex and petIndex > 0 then
                    if entMgr:GetServerId(petIndex) == actor_id then
                        return party:GetMemberServerId(i);
                    end
                end
            end
        end
    end
    return 0;
end

local function ensure_player(owner_id)
    if not dps.players[owner_id] then
        dps.players[owner_id] = {
            name   = get_entity_name(owner_id),
            damage = 0,
            hits   = 0,
            misses = 0,
        };
    end
    local p = dps.players[owner_id];
    if not p.name or p.name:find('^ID:') or p.name == '' then
        p.name = get_entity_name(owner_id);
    end
    return p;
end

local function add_damage(owner_id, amount)
    if amount <= 0 or amount > 999999 then return; end
    if owner_id == 0 then return; end
    local p = ensure_player(owner_id);
    p.damage = p.damage + amount;
    p.hits   = p.hits + 1;
end

local function add_miss(owner_id)
    if owner_id == 0 then return; end
    local p = ensure_player(owner_id);
    p.misses = p.misses + 1;
end

local function accuracy_of(p)
    local total = (p.hits or 0) + (p.misses or 0);
    if total <= 0 then return 0; end
    return (p.hits / total) * 100;
end

local function reset_data()
    dps.players    = {};
    dps.start_time = os.clock();
    print(chat.header(addon.name):append(chat.message('Totals cleared. Timer restarted.')));
end

local function prune_left_members()
    local to_remove = {};
    for id, _ in pairs(dps.players) do
        if not is_party_member(id) then
            table.insert(to_remove, id);
        end
    end
    for _, id in ipairs(to_remove) do
        dps.players[id] = nil;
    end
end

local function build_sorted_list()
    local list = {};
    local total_damage = 0;
    for id, p in pairs(dps.players) do
        table.insert(list, {
            id     = id,
            name   = p.name or get_entity_name(id),
            damage = p.damage or 0,
            hits   = p.hits or 0,
            misses = p.misses or 0,
            acc    = accuracy_of(p),
        });
        total_damage = total_damage + (p.damage or 0);
    end
    table.sort(list, function(a, b) return a.damage > b.damage; end);
    return list, total_damage;
end

--- Post summary to the chosen chat channel.
--- channel: 'p' = party, 's' = say, 'l' = linkshell
--- One person per line, with a long delay so FFXI does not drop messages.
local function report_to_chat(channel)
    channel = channel or 'p';
    local prefix;
    if channel == 's' or channel == 'say' then
        prefix = '/s ';
    elseif channel == 'l' or channel == 'ls' or channel == 'linkshell' then
        prefix = '/l ';
    else
        prefix = '/p ';
    end

    local elapsed = math.max(os.clock() - dps.start_time, 1.0);
    local list, total_damage = build_sorted_list();

    if #list == 0 then
        print(chat.header(addon.name):append(chat.message('Nothing to report yet.')));
        return;
    end

    local lines = {};
    table.insert(lines, string.format('DPS Report (%.0fs) — Total: %d (%.1f dps)',
        elapsed, total_damage, total_damage / elapsed));

    for i, entry in ipairs(list) do
        if i > 8 then break; end
        local dps_val = entry.damage / elapsed;
        table.insert(lines, string.format('%d. %s  %d dmg  %.1f dps  %.0f%% acc',
            i, entry.name, entry.damage, dps_val, entry.acc));
    end

    -- 1.2 seconds between each line — plenty of time for the server
    local chatMgr = AshitaCore:GetChatManager();
    for i, line in ipairs(lines) do
        local delay = (i - 1) * 1.2;
        local msg = prefix .. line;
        ashita.tasks.once(delay, function()
            chatMgr:QueueCommand(1, msg);
        end);
    end

    print(chat.header(addon.name):append(chat.message(
        string.format('Sending %d lines to %s (1.2s apart)...', #lines,
            (channel == 's' and 'say') or (channel == 'l' and 'linkshell') or 'party'))));
end

--=============================================================================
-- Action packet parsing (0x28)
--=============================================================================
local function parse_action_packet(e)
    if e.id ~= 0x28 then return; end

    local data = e.data_raw;
    local bitOffset = 40;
    local maxBits = e.size * 8;

    local function unpack(bits)
        if (bitOffset + bits) > maxBits then
            return 0;
        end
        local val = ashita.bits.unpack_be(data, 0, bitOffset, bits);
        bitOffset = bitOffset + bits;
        return val;
    end

    local actor_id     = unpack(32);
    local target_count = unpack(6);
    bitOffset = bitOffset + 4;
    local action_type  = unpack(4);
    unpack(32);
    bitOffset = bitOffset + 32;

    -- Categories that deal damage or can miss:
    -- 1 melee, 2 ranged finish, 3 WS, 4 magic, 6 JA, 11 NPC skill,
    -- 13 pet TP, 14 DNC JA, 15 RUN JA
    local valid = {
        [1] = true, [2] = true, [3] = true, [4] = true,
        [6] = true, [11] = true, [13] = true, [14] = true, [15] = true,
    };
    if not valid[action_type] then return; end

    local owner_id = resolve_to_owner(actor_id);
    if owner_id == 0 then return; end

    for _ = 1, target_count do
        unpack(32);                          -- target id
        local action_count = unpack(4);

        for _ = 1, action_count do
            unpack(5);                       -- reaction
            unpack(12);                      -- animation
            unpack(7);                       -- special effect
            unpack(3);                       -- knockback
            local param   = unpack(17);
            local message = unpack(10);
            unpack(31);                      -- flags

            local add_param = 0;
            local add_message = 0;
            if unpack(1) == 1 then
                unpack(10);
                add_param = unpack(17);
                add_message = unpack(10);
            end

            if unpack(1) == 1 then
                unpack(10);
                unpack(14);
                unpack(10);
            end

            -- Damage (also counts as a hit for accuracy)
            if is_damage_message(message) and param > 0 and param < 100000 then
                add_damage(owner_id, param);
            elseif is_miss_message(message) then
                add_miss(owner_id);
            end

            -- Additional-effect damage
            if is_damage_message(add_message) and add_param > 0 and add_param < 100000 then
                add_damage(owner_id, add_param);
            end
        end
    end
end

--=============================================================================
-- Events
--=============================================================================
ashita.events.register('load', 'dps_load_cb', function()
    dps.player_id  = get_player_id();
    dps.start_time = os.clock();
    print(chat.header(addon.name):append(chat.message('Loaded. /dps to toggle, /dps report to post to party.')));
end);

ashita.events.register('command', 'dps_command_cb', function(e)
    local args = e.command:args();
    if #args == 0 then return; end

    local cmd = string.lower(args[1]);
    if cmd ~= '/dps' then return; end

    e.blocked = true;

    if #args == 1 then
        dps.is_open[1] = not dps.is_open[1];
        return;
    end

    local sub = string.lower(args[2] or '');
    if sub == 'reset' or sub == 'clear' then
        reset_data();
    elseif sub == 'report' or sub == 'r' then
        local channel = string.lower(args[3] or 'p');
        report_to_chat(channel);
    elseif sub == 'help' then
        print(chat.header(addon.name):append(chat.message('Commands:')));
        print(chat.header(addon.name):append(chat.message('/dps              Toggle window')));
        print(chat.header(addon.name):append(chat.message('/dps reset        Clear totals & restart timer')));
        print(chat.header(addon.name):append(chat.message('/dps report [p|s|l]  Post to party/say/linkshell')));
        print(chat.header(addon.name):append(chat.message('/dps help         This help')));
    else
        print(chat.header(addon.name):append(chat.message('Unknown sub-command. Type /dps help')));
    end
end);

ashita.events.register('packet_in', 'dps_packet_in_cb', function(e)
    if e.id == 0x28 then
        local pid = get_player_id();
        if pid ~= 0 then
            dps.player_id = pid;
        end
        parse_action_packet(e);
    end
end);

--=============================================================================
-- Render
--=============================================================================
ashita.events.register('d3d_present', 'dps_present_cb', function()
    if not dps.is_open[1] then return; end

    local pid = get_player_id();
    if pid ~= 0 then
        dps.player_id = pid;
    end

    prune_left_members();

    local elapsed = math.max(os.clock() - dps.start_time, 1.0);
    local list, total_damage = build_sorted_list();

    imgui.SetNextWindowSize({ 360, 0 }, ImGuiCond_FirstUseEver);
    imgui.SetNextWindowSizeConstraints({ 280, 130 }, { 560, 700 });

    if imgui.Begin('DPS', dps.is_open, ImGuiWindowFlags_NoCollapse) then
        imgui.Text(string.format('Time: %.0fs', elapsed));
        imgui.SameLine();

        local avail = imgui.GetContentRegionAvail();
        local btn_w = 58;
        imgui.SetCursorPosX(imgui.GetCursorPosX() + math.max(avail - (btn_w * 2 + 8), 0));

        if imgui.Button('Report', { btn_w, 0 }) then
            report_to_chat('p');
        end
        if imgui.IsItemHovered() then
            imgui.SetTooltip('Post summary to party chat (/dps report)');
        end

        imgui.SameLine();
        if imgui.Button('Reset', { btn_w, 0 }) then
            reset_data();
        end
        if imgui.IsItemHovered() then
            imgui.SetTooltip('Clear all totals and restart the timer');
        end

        imgui.Separator();

        if #list == 0 then
            imgui.TextColored({ 0.65, 0.65, 0.65, 1.0 }, 'No damage recorded yet.');
            imgui.TextColored({ 0.55, 0.55, 0.55, 1.0 }, 'Fight something, then /dps report');
        else
            -- Name | Dmg | DPS | Acc
            imgui.Columns(4, 'dps_cols', false);
            imgui.SetColumnWidth(0, 110);
            imgui.SetColumnWidth(1, 70);
            imgui.SetColumnWidth(2, 60);
            imgui.SetColumnWidth(3, 70);

            imgui.Text('Name');
            imgui.NextColumn();
            imgui.Text('Damage');
            imgui.NextColumn();
            imgui.Text('DPS');
            imgui.NextColumn();
            imgui.Text('Acc');
            imgui.NextColumn();
            imgui.Separator();

            for _, entry in ipairs(list) do
                local dps_val = entry.damage / elapsed;
                local is_me   = (entry.id == dps.player_id);

                if is_me then
                    imgui.TextColored({ 0.35, 1.0, 0.45, 1.0 }, entry.name);
                else
                    imgui.Text(entry.name);
                end
                imgui.NextColumn();

                imgui.Text(string.format('%d', entry.damage));
                imgui.NextColumn();

                imgui.Text(string.format('%.1f', dps_val));
                imgui.NextColumn();

                local total_swings = entry.hits + entry.misses;
                if total_swings > 0 then
                    imgui.Text(string.format('%.0f%%', entry.acc));
                else
                    imgui.TextColored({ 0.5, 0.5, 0.5, 1.0 }, '--');
                end
                imgui.NextColumn();
            end

            imgui.Columns(1);
            imgui.Separator();
            imgui.Text(string.format('Party Total:  %d   (%.1f dps)',
                total_damage, total_damage / elapsed));
        end
    end
    imgui.End();
end);
